﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;




namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        private RumahDBEntities1 db = new RumahDBEntities1();

        public ActionResult Index()
        {
            return View(db.tblRumahs.ToList());
        }

        public ActionResult GetLocations()
        {
            var locations = db.tblRumahs.ToList();
            return Json(locations, JsonRequestBehavior.AllowGet);
        }

        public void GetTipeRumah( )
        {
            string[] TipeRumahArr = { "36", "45", "72" };
            var TipeRumah = new List<SelectListItem>();
            for (int i = 0; i < TipeRumahArr.Length; i++)
            {
                TipeRumah.Add(new SelectListItem() { Text = TipeRumahArr[i], Value = TipeRumahArr[i] });
            }

            ViewBag.TipeRumah = TipeRumah;
        }

            public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblRumah rumah = db.tblRumahs.Find(id);
            if (rumah == null)
            {
                return HttpNotFound();
            }
            return View(rumah);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Create()
        {
            GetTipeRumah();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Tipe_Rumah,Alamat,Latitude,Longitude")] tblRumah rumah)
        {
            if (ModelState.IsValid)
            {
                db.tblRumahs.Add(rumah);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(rumah);
        }

        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblRumah rumah = db.tblRumahs.Find(id);
            if (rumah == null)
            {
                return HttpNotFound();
            }

            //karena kesalahan tipe data di awal (char)
            if (rumah.Tipe_Rumah != null)
            {
                rumah.Tipe_Rumah = rumah.Tipe_Rumah.Trim();
            }

            GetTipeRumah();
            return View(rumah);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Tipe_Rumah,Alamat,Latitude,Longitude")] tblRumah rumah)
        {
            if (ModelState.IsValid)
            {
                db.Entry(rumah).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(rumah);
        }

        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tblRumah rumah = db.tblRumahs.Find(id);
            if (rumah == null)
            {
                return HttpNotFound();
            }
            return View(rumah);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            tblRumah rumah = db.tblRumahs.Find(id);
            db.tblRumahs.Remove(rumah);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}